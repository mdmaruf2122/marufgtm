# MarufShop Deploy-Ready

## Frontend
- Folder: frontend/
- Env: .env -> set REACT_APP_API_URL to your backend URL
- Deploy on Vercel

## Backend
- Folder: backend/
- Run: npm install && npm start
- Deploy on Render.com

## Dummy Products
- 100+ Electronics products
- Images, price, rating, description, stock
