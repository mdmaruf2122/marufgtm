import React from 'react';
export default function App() { return <div>MarufShop Frontend Placeholder</div>; }